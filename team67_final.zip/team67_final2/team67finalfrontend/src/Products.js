// ONLY TO KEEP TRACK OF OUR DATA NOT ACTUALLY USED IN THE PROJECT
// export const Products = [
//     {
//       "_id": 1,
//       "title": "Bee",
//       "price": 20,
//       "description": "This smiling, little creature is perfect for any bee lover out there.",
//       "category": "creatures",
//       "image": "http://127.0.0.1:4000/images/bee_side2.jpg",
//       "rating": { "rate": 3.9, "count": 120 }
//     },
//     {
//       "_id": 2,
//       "title": "Book Cover - Blue",
//       "price": 30,
//       "description": "This blue book cover can hold medium-large sized books. It features a button to clasp shut and keep the books contained.",
//       "category": "books",
//       "image": "http://127.0.0.1:4000/images/book_cover_blue.jpg",
//       "rating": { "rate": 4.1, "count": 259 }
//     },
//     {
//       "_id": 3,
//       "title": "Book Cover - Brown",
//       "price": 30,
//       "description": "The brown book cover can contain any small-medium sized books. It's also perfect for small journals! The front features a button to clasp the cover shut.",
//       "category": "books",
//       "image": "http://127.0.0.1:4000/images/book_cover_brown.jpg",
//       "rating": { "rate": 4.7, "count": 500 }
//     },
//     {
//       "_id": 4,
//       "title": "Corgi",
//       "price": 20,
//       "description": "A cute corgi plushie is great for anyone who loves dogs, especially corgi lovers!",
//       "category": "creatures",
//       "image": "http://127.0.0.1:4000/images/corgi_front.jpg",
//       "rating": { "rate": 2.1, "count": 430 }
//     },
//     {
//       "_id": 5,
//       "title": "Frog With Mushroom",
//       "price": 20,
//       "description": "This piece features a cute frog holding a mushroom friend. I find this item is perfect for anyone who loves earthly creatures!",
//       "category": "creatures",
//       "image": "http://127.0.0.1:4000/images/frog_mush_front.jpg",
//       "rating": { "rate": 4.6, "count": 400 }
//     },
//     {
//       "_id": 6,
//       "title": "White Dinosaur",
//       "price": 20,
//       "description": "My dinosaur plushie can sit on any shelf or table, and is great for any lover of prehistoric creatures.",
//       "category": "creatures",
//       "image": "http://127.0.0.1:4000/images/white_dino_front.jpg",
//       "rating": { "rate": 3.9, "count": 70 }
//     },
//     {
//       "_id": 7,
//       "title": "Rainbow Sweater",
//       "price": 60,
//       "description": "This rainbow sweater is one of my newest creations. You will find that this rainbow sweater is soft, warm, and cozy.",
//       "category": "clothes",
//       "image": "http://127.0.0.1:4000/images/rainbow_sweater.webp",
//       "rating": { "rate": 3, "count": 400 }
//     },
//     {
//       "_id": 8,
//       "title": "Crochet Top",
//       "price": 35,
//       "description": "Crochet tank top that has a corset back, which can be adjusted, along with adjustable neck ties. Great to wear in the summertime!",
//       "category": "clothes",
//       "image": "http://127.0.0.1:4000/images/tank_front.jpg",
//       "rating": { "rate": 1.9, "count": 100 }
//     }
// ]
  