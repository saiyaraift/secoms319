function submitted(){
  alert("Thank you! Your order has been received");

}